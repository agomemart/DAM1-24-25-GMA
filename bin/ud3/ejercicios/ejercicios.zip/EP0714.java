package ud3.ejercicios;

public class EP0714 {
    public static void main(String[] args) {
        Cambio.desglosarCambio(14.58);
        }
        
            
        
}
