//Adrián Gómez Martínez
package ud2.gmaexamen;

/*Las bombillas tienen dos factores que marcan cuándo dejan de funcionar. Por un lado
tienen un número máximo de horas de iluminación y por otro tienen un número máximo de
encendidos. Si enciendes la bombilla y no la vuelves a apagar durará muchísimas horas.
Pero si la enciendes y apagas continuamente, dejará de funcionar mucho antes.
Escribe una función causaFinBombilla() que acepte como parámetros de entrada tres
números enteros positivos.
● El primero es el número de horas que aguanta la bombilla encendida.
● El segundo es el número de encendidos que es capaz de soportar.
● El último es el número de horas que se estima se mantendrá la lámpara encendida
en cada uso (como mucho 10).
La función deberá devolver la causa de la muerte de la bombilla LED como una de las
siguientes cadenas de caracteres:
● "HORAS" si se alcanza el número máximo de horas encendida.
● "ENCENDIDOS" si se alcanza el número máximo de encendidos.
● "ENCENDIDOS + HORAS" si se alcanzan ambos límites simultáneamenes.
● "ERROR" si alguno de los parámetros de entrada tiene un valor incorrecto. */
public class DuracionBombillas {
    public static void causaFinBombilla(int numHorasAguanteEncendida, int numEncendidos, int numHorasBombillaEncendida) {
        if (numHorasAguanteEncendida > 0 && numEncendidos > 0 && numHorasBombillaEncendida > 0){
            if (numHorasBombillaEncendida >= 10 && numEncendidos > 10) {
                System.out.println("Encendidos + horas");
            } else if (numEncendidos > 10) {
                System.out.println("Encendidos");
            } else if (numHorasBombillaEncendida > numHorasAguanteEncendida || numHorasBombillaEncendida >= 10) {
                System.out.println("Horas");
            } else {
                System.out.println("Error");
            }
        } else {
            System.out.println("Error");
        }
       
    }
    public static void main(String[] args) {
        causaFinBombilla(1000, 100, 1);
    }
}
