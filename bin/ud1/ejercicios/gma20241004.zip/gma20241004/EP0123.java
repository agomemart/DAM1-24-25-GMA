package ud1.ejercicios.gma20241004;

import java.util.Scanner;

/**
 * Escribe un programa que convierta unidades de masa entre kilogramos y libras o viceversa. El programa solicitará al usuario la cantidad de masa y la unidad de medida origen (kilogramos o libras).
1 kilogramo = 1000 gramos
1 libra = 453.592 gramos
El programa deberá manejar las conversiones automáticamente y mostrar el resultado al usuario. Utiliza el operador ternario para evaluar la unidad de medida introducida por el usuario. El programa mostrará por pantalla el resultado con la unidad de medida adecuada.

 */
public class EP0123 {
    public static void main(String[] args) {
        double kg;

        Scanner sc = new Scanner(System.in);
        System.out.print("Insterta kg: ");
        sc.nextDouble();
        
        double libras = 0.453592*kg;
        System.out.println("Los kg introducidos serían: " + libras + "libras");

        System.out.print("Inserta libras: ");
        double libras2 = sc.nextDouble();

        double librasAkg = libras2/0.453592;
        System.out.println("En kg serían: " + librasAkg + "kg");
    }
}
