package ud5.rol;

enum TipoArmadura {
    YELMO, ARMADURA, ESCUDO;
}
