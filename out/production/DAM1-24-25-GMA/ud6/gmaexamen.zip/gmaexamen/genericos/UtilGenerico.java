package ud6.gmaexamen.genericos;

import java.util.*;

//Adrián Gómez Martínez
public class UtilGenerico<T> {
    public List<T> sinRepetidos(List<T> lista) {
        List<Integer> sinRepetidos = new ArrayList<>();
        sinRepetidos.addAll((Collection<? extends Integer>) lista);
        return (List<T>) sinRepetidos;
    }

    public Collection<T> filtrarMayores(Collection<T> elementos, T elemento, Comparator<T> comp) {

        return null;
    }

    public static void main(String[] args) {
        List<Integer> lista = Arrays.asList(1, 2, 3, 3, 4);
        List<Integer> sinRepetidos = new ArrayList<>();

        Collection <String> elementos;
        String str = "Prueba";

    }
}
